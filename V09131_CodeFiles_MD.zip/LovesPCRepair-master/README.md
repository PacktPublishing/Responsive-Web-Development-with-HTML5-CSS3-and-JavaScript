# LovesPCRepair

This is a website template built for Packt Publishing by;
# Aubrey W. Love II

Within this website, we will find;
1) index.html ~ The main page for our website.
2) gui.css ~ The back-end code to make our website responsive & add style to our site.
3) functions.js ~ Another back-end code to make our website have some functionality.
